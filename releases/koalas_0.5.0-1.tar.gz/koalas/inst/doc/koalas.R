## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width=8, fig.height=4
)

options("pboptions" = list(type = "none"))

## ----eval=FALSE---------------------------------------------------------------
# install.packages(c("koalas","tidyverse"),
#   repos=c("https://ku-awdc.r-universe.dev/", "https://cran.rstudio.com/"))

## ----eval=FALSE---------------------------------------------------------------
# install.packages(c("IPDMR","remotes"),
#   repos=c("https://ku-awdc.r-universe.dev/", "https://cran.rstudio.com/"))

## ----eval=FALSE---------------------------------------------------------------
# remotes::install_github("ku-awdc/koalas")

## -----------------------------------------------------------------------------
library("koalas")
model <- KoalasV2$new()
model$burnin()

## -----------------------------------------------------------------------------
library("ggplot2")
theme_set(theme_light())

model$autoplot()

## -----------------------------------------------------------------------------
baseline <- model$clone(deep=TRUE)
baseline$run(10, frequency=0)
baseline$autoplot() +
  geom_vline(xintercept=baseline$run_dates, lty="dashed")

## -----------------------------------------------------------------------------
phase1 <- assess_interventions(
  model,
  years = 2,
  frequency = 1:4,
  prop_active = seq(0, 1, by=0.1),  # Change to by=0.01 for more precise results
  prop_targeted = 0.0
)

library("dplyr")
phase1 |>
  filter(Prevalence <= 5) |>
  group_by(Frequency) |>
  arrange(PropActive) |>
  slice(1L)

## -----------------------------------------------------------------------------
phase1 |>
  ggplot(aes(x=PropActive, y=Prevalence, col=Frequency)) +
  geom_line() +
  geom_hline(yintercept=5, lty="dashed") +
  theme(legend.position="bottom")

## -----------------------------------------------------------------------------
phase1 |>
  ggplot(aes(x=PropActive, y=Koalas, col=Frequency)) +
  geom_line() +
  theme(legend.position="bottom")

## -----------------------------------------------------------------------------
phase1_targeted <- assess_interventions(
  model,
  years = 2,
  frequency = 1:4,
  prop_active = 0.0,
  prop_targeted = seq(0, 1, by=0.1)  # Change to by=0.01 for more precise results
)
phase1_targeted |>
  ggplot(aes(x=PropTargeted, y=Prevalence, col=Frequency)) +
  geom_line() +
  geom_hline(yintercept=5, lty="dashed") +
  theme(legend.position="bottom") +
  ylim(0,100)

## -----------------------------------------------------------------------------
phase1_both <- assess_interventions(
  model,
  years = 2,
  frequency = 1:4,
  prop_active = seq(0, 1, by=0.1),  # Change to by=0.01 for more precise results
  prop_targeted = 0.8
)
phase1_both |>
  ggplot(aes(x=PropActive, y=Prevalence, col=Frequency)) +
  geom_line() +
  geom_hline(yintercept=5, lty="dashed") +
  theme(legend.position="bottom") +
  ylim(0,100)

## -----------------------------------------------------------------------------
model$run(2, frequency = 4, prop_active = 0.47, prop_targeted = 0.0)

## -----------------------------------------------------------------------------
model$autoplot()

## -----------------------------------------------------------------------------
phase2 <- assess_interventions(
  model,
  years = 8,
  frequency = 1:4,
  prop_active = seq(0, 1, by=0.1),  # Change to by=0.01 for more precise results
  prop_targeted = 0.0
)
phase2 |>
  filter(Prevalence <= 5) |>
  group_by(Frequency) |>
  arrange(PropActive) |>
  slice(1L)

## -----------------------------------------------------------------------------
library("tidyr")

phase2 |>
  pivot_longer("Prevalence":"Koalas", names_to="Metric", values_to="Value") |>
  ggplot(aes(x=PropActive, y=Value, col=Frequency)) +
  geom_line() +
  facet_wrap(~Metric, ncol=1, scales="free_y") +
  geom_hline(data=tibble(Metric="Prevalence", ll=5), mapping=aes(yintercept=ll), lty="dashed")

## -----------------------------------------------------------------------------
model$run(8, frequency = 2, prop_active = 0.45)
model$autoplot() +
  geom_vline(xintercept=model$run_dates, lty="dashed")

## -----------------------------------------------------------------------------
library("koalas")
model <- KoalasV2$new()

## -----------------------------------------------------------------------------
model$set_state(S=299, I=1, R=0, Af=0, Cf=0)

## -----------------------------------------------------------------------------
model$set_parameters(birthrate=0.38)

## -----------------------------------------------------------------------------
model$state |> simplify2array()
model$parameters |> simplify2array()

## -----------------------------------------------------------------------------
model$update(21)

## -----------------------------------------------------------------------------
model$results_wide

## -----------------------------------------------------------------------------
model$active_intervention(proportion=0.5)

## -----------------------------------------------------------------------------
model$update(21)
model$results_wide

## -----------------------------------------------------------------------------
model <- KoalasV2$new()
model$update(5)
model$results_wide

## -----------------------------------------------------------------------------
model$results_long

## -----------------------------------------------------------------------------
sessionInfo()

